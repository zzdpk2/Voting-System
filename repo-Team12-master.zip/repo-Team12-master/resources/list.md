Cloud Link: https://pan.baidu.com/s/1ypR9xGdN2e2SgWftkgtf2A 

Code: 4y38 

------

Text books, software(Astah and StarUML) and other resources are in this link.
