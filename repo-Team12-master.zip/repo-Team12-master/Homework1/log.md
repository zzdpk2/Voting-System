## Sept 14 
#### 1.This is a log for Homework1. If someone update the github, please notify the info and correspounding time in this log file.
#### 2.Trim the name of file "ieeeSoftwareRequirements.docx". 
## Sept 16 
#### 1.Add rubrics and specification for Homework1. 
## Sept 23
#### 1.Push final draft of Homework1.
#### 2.Revise name of Homework1 and delete other files.
