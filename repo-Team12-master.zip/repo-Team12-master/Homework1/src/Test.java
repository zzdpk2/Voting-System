public class Test{
    public static void main(){
        System.out.println("Hello CSCi5801!");
    }
}