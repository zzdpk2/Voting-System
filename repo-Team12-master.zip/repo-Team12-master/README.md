# CSCi 5801: Software Engineering I

#### Team 12 members: 

|  Yinjing Zhang([zhan4973](mailto://zhan4973@umn.edu))   |    Sunny Qin([qing0002](mailto://qing0002@umn.edu))     |
| :--------------------------------------------: | :--------------------------------------------: |
| **Xiaohui Chao([chao0070](mailto://chao0070@umn.edu))** | **Zhendong Zhu([zhu00100](mailto://zhu00100@umn.edu))** |

##### `Recent news:`

New repository is created.  Homework 1 is due on Sept 23.

Homework 1 is finished on Sept 23.

The doc of Project 1 is due on October 10.(extended to Oct 12)

The doc of Project 1 is finished on Oct 12.

The program of project 1 is finished on Nov 18.

The program of project 2 is finished on Dec 12.
