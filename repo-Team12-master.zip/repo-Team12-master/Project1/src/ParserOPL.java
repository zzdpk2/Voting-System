package mypackage;
import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.lang.*;

/**
* ParserOPL.java - a class to parse the csv file for CPL voting.
* @author  Yingjin Zhang
* @since   2019-11-16
*/
public class ParserOPL{
  /**
  *  Constructor for OPL parser
  */
  public ParserOPL(){
  }

  /**
  * parse file for OPL process, get the useful info, count ballots and save them into an object array
  * @param filename Input csv filename, ex. "voting.csv"
  * @param auditfile auditfile name, by default: "audit.txt"
  * @return An object array that contains num_seats, num_ballots, party_names, party_ballots, cand_ballots
  * @throws FileNotFoundException
  */

  public static Object[] parse_opl(String filename, String auditfile) throws FileNotFoundException{
    Scanner scanner = new Scanner(new File(filename));
    scanner.useDelimiter("\n");
    String type = scanner.next();
    WriteAudit audit = new WriteAudit();
    File file = new File(auditfile);
    file.delete();
    audit.writeAuditFile(type, auditfile);

    // Get useful info line by line until arrive the specific ballot
    int num_seats = Integer.parseInt(scanner.next());
    int num_ballots = Integer.parseInt(scanner.next());
    int num_cand = Integer.parseInt(scanner.next());
    audit.writeAuditFile("number of seats: "+ Integer.toString(num_seats), auditfile);
    audit.writeAuditFile("number of ballots: "+ Integer.toString(num_ballots), auditfile);
    audit.writeAuditFile("number of candidates: "+ Integer.toString(num_cand), auditfile);

    ArrayList<String> party_names = new ArrayList<String>();
    ArrayList<String> cand_names = new ArrayList<String>();
    ArrayList<Integer> cand_parties = new ArrayList<Integer>();
    int j = 0;
    String old_party_name = "Hello";
    Hashtable<String, Integer> party_ballots = new Hashtable<String, Integer>();
    Hashtable<String, Integer> cand_party_ballots = new Hashtable<String, Integer>();
    ArrayList<Hashtable<String, Integer>> cand_ballots = new ArrayList<Hashtable<String, Integer>>();

    // Parser candidate list, convert them into required type, and initialize them with 0 votes at this step
    for(int i=0; i<num_cand; i++){
      String cand = scanner.next();
      cand = cand.substring(1, cand.length()-1);
      String[] cand_party = cand.split(",");
      String cand_name = cand_party[0];
      String party_name = cand_party[1];
      if(!party_name.equals(old_party_name) && old_party_name.equals("Hello")){
        j = 0;
        party_names.add(party_name);
        cand_names.add(cand_name);
        cand_parties.add(j);
        party_ballots.put(party_name, 0);
        old_party_name = party_name;
        cand_party_ballots.put(cand_name, 0);
      }
      // Different party's candidate goes into different hashtable
      else if(!party_name.equals(old_party_name) && !old_party_name.equals("Hello")){
        j++;
        party_names.add(party_name);
        cand_names.add(cand_name);
        cand_parties.add(j);
        party_ballots.put(party_name, 0);
        old_party_name = party_name;
        cand_ballots.add(cand_party_ballots);
        cand_party_ballots = new Hashtable<String, Integer>();
        cand_party_ballots.put(cand_name, 0);
      }

      // Same party's candidate goes into same hashtable
      else{
        cand_names.add(cand_name);
        cand_parties.add(j);
        cand_party_ballots.put(cand_name, 0);
      }
      if(i==num_cand-1)
      {
        cand_ballots.add(cand_party_ballots);
      }
    }

    audit.writeAuditFile("Initialize party ballots: "+ party_ballots.toString(), auditfile);
    int k = 0 ;
    for(Hashtable<String, Integer> hash_p: cand_ballots){

      audit.writeAuditFile("Initialize candidate ballots for party "+ party_names.get(k) +": "+ hash_p.toString(), auditfile);
      k++;
    }

    // Parse ballots, add 1 to corresponding candidates
    while(scanner.hasNext()){
      String ballot = scanner.next();
      for(int i=0; i<num_cand; i++){
        if(ballot.substring(i,i+1).equals("1")){
          Hashtable<String, Integer> hash_p = cand_ballots.get(cand_parties.get(i));
            for(Map.Entry<String,Integer> entry: hash_p.entrySet()){
              if(entry.getKey().equals(cand_names.get(i))){
                entry.setValue(entry.getValue()+1);
                audit.writeAuditFile("Candidate "+ cand_names.get(i) + " votes + 1. Current votes: " + Integer.toString(entry.getValue()), auditfile);

                break;
              }
            }
        }
      }
    }

    int n = 0 ;
    for(Hashtable<String, Integer> hash_p: cand_ballots){
      audit.writeAuditFile("Candidate parser results for party "+ party_names.get(n) +": "+ hash_p.toString(), auditfile);
      n++;
    }

    // Update party_ballots by adding up all candidates' ballots in that party
    int p = 0;
    for(Hashtable<String, Integer> hash_p: cand_ballots){
      int sum = 0;
      for(Map.Entry<String,Integer> entry: hash_p.entrySet()){
        sum = sum + entry.getValue();
      }
      for(Map.Entry<String,Integer> e: party_ballots.entrySet()){
        if(e.getKey().equals(party_names.get(p))){
          e.setValue(sum);
        }
      }
      p++;
    }

    audit.writeAuditFile("Party parser results: "+ party_ballots.toString() + "\n", auditfile);

    return new Object[] {num_seats, num_ballots, party_names, party_ballots, cand_ballots};
  }
}
