## Sept 14 
#### 1.This is a log for Homework1. If someone update the github, please notify the info and correspounding time in this log file.
#### 2.Trim the name of file "ieeeSoftwareRequirements.docx". 
## Sept 16 
#### 1.Add rubrics and specification for Hwk1. 
#### 2.Modify the file structure: create the docs directory and put some docs into it.
#### 3.Add test code files.
## Sept 19
#### 1.Allocate missions to members:
#### Rex Zhu: Chapter 1, 3
#### Xiaohui Chao: Chapter 2
#### Sunny Qin: Chapter 4
#### Yinjing Zhang: Chapter 5
